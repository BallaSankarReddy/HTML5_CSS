

  // Wait for the DOM to be fully loaded
  document.addEventListener('DOMContentLoaded', function() {
    const header = document.getElementById('navbarNav');
    const content = document.querySelector('.content');
    
    // Add click event on the header to toggle blur on content
    header.addEventListener('click', function(event) {
      content.classList.toggle('blur'); // Toggle blur effect on the content
      event.stopPropagation(); // Prevent event from bubbling up to body
    });

    // Add click event on the body to remove blur
    document.body.addEventListener('click', function() {
      content.classList.remove('blur'); // Remove blur when clicking anywhere else
    });
  });
